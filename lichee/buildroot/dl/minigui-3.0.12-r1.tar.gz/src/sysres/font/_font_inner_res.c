//the empty inner list file

#ifdef _MGINCORE_RES

//declear arrays
static INNER_RES __mgir_font_inner_res [] = {
    { 0xfffffff, (void*)NULL, 0, 0}
};

#endif // _MGINCORE_RES

