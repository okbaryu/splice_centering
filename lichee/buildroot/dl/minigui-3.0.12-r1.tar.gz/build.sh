#! /bin/sh
# which can be reset
# INSTALL_DIR
# EXTRA_LIBS
# EXTRA_INC
#-----------------------------------------------------------------------------------------

ANDROID_BUILD_TOP=$CAMLINUX_BUILD_TOP
ANDROID_PRODUCT_OUT=$ANDROID_BUILD_TOP/out/target/product/hsiot-zig
ANDROID_TOOLCHAIN=$ANDROID_BUILD_TOP/prebuilts/gcc/linux-x86/arm/arm-linux-androideabi-4.6/bin

if [ -z $ANDROID_TOOLCHAIN ]; then
	echo "-__-|| sorry, please import camdroid environment variable"	
	exit 1
fi

NAME=`whoami`
PWD=`pwd`
SYS_OUT=$ANDROID_PRODUCT_OUT
BUILD_TOP=$ANDROID_BUILD_TOP
BASE_PATH=$ANDROID_TOOLCHAIN
SYS_LIB_PATH="/system/lib"
BIONIC="/bionic"
CROSS_TOOL="/arm-linux-androideabi-"
#-----------------------------------------------------------------------------------------
INSTALL_DIR="$PWD/tmp"
EXTRA_LIBS_BASE="$INSTALL_DIR/lib"
EXTRA_LIBS="$EXTRA_LIBS_BASE" 
EXTRA_INC_BASE="$BUILD_TOP/frameworks/include/include_gui"
EXTRA_INC="$EXTRA_INC_BASE -I$BUILD_TOP/external/jpeg -I$BUILD_TOP/external/libpng -I$BUILD_TOP/frameworks/include/include_gui -I$BUILD_TOP/frameworks/include/include_gui/freetype2"
EXTRA_LDFLAG="-lpng -ljpeg -lfreetype"
SYS_LIB=$SYS_OUT$SYS_LIB_PATH
APREFIX=$BUILD_TOP$BIONIC
CROSS=$BASE_PATH$CROSS_TOOL
#-----------------------------------------------------------------------------------------
LD_FLAG="-nostdlib -lm -lstdc++ -lc -ldl -Bdynamic -Wl,-dynamic-linker,/system/bin/linker"
LDFLAGS="-L$SYS_LIB $LD_FLAG -L$INSTALL_DIR/libi -L$BUILD_TOP/frameworks/prebuilts -lts"
if [ -n $EXTRA_LIBS_BASE ]; then
	LDFLAGS="$LDFLAGS -L$EXTRA_LIBS $EXTRA_LDFLAG"
fi
echo LDFLAGS=$LDFLAGS
#-----------------------------------------------------------------------------------------
CPPFLAGS=
CPPFLAGS="$CPPFLAGS-I$APREFIX/libm/include"
CPPFLAGS="$CPPFLAGS -I$APREFIX/libc/include"
CPPFLAGS="$CPPFLAGS -I$APREFIX/libc/arch-arm/include"
CPPFLAGS="$CPPFLAGS -I$APREFIX/libstdc++/include"
CPPFLAGS="$CPPFLAGS -I$APREFIX/libc/kernel/common"
CPPFLAGS="$CPPFLAGS -I$APREFIX/libc/kernel/arch-arm"
CPPFLAGS="$CPPFLAGS -I$INSTALL_DIR/include"
if [ -n $EXTRA_BASE ]; then
	CPPFLAGS="$CPPFLAGS -I$EXTRA_INC"
fi
echo CPPFLAGS=$CPPFLAGS
#-----------------------------------------------------------------------------------------
export LDFLAGS="$LDFLAGS"
export CPPFLAGS="$CPPFLAGS"
export CC="$CROSS"gcc
export CXX="$CROSS"g++
export LD="$CROSS"ld
export AS="$CROSS"as
export AR="$CROSS"ar
export STRIP="$CROSS"strip
export INSTALL_DIR="$INSTALL_DIR"
#-----------------------------------------------------------------------------------------
./configure --prefix=${INSTALL_DIR} --host=arm-linux --build=i386-linux --with-targetname=fbcon --enable-sunximin --enable-savescreen \
	--enable-jpgsupport --enable-debug --enable-adv2dapi --enable-unicodesupport --with-ttfsupport=ft2 --enable-bmpfsupport \
	--with-ft2-includes=$BUILD_TOP/frameworks/include/include_gui/freetype2
#-----------------------------------------------------------------------------------------
make
make install-strip 
#-----------------------------------------------------------------------------------------
cp ${INSTALL_DIR}/lib/libminigui_ths-3.0.so.12.0.0 ${BUILD_TOP}/frameworks/prebuilts/libminigui_ths.so
cp -rf ${INSTALL_DIR}/include/minigui/* ${BUILD_TOP}/frameworks/include/include_gui/minigui/
ls -lh ${BUILD_TOP}/frameworks/prebuilts/libminigui_ths.so 
#-----------------------------------------------------------------------------------------
